JLC's Internet TV
v1.0 Beta 5e

Copyright � 2007 Joakim L. Christiansen.
All rights reserved.

http://www.jlc-software.com


About:
------
JLC's Internet TV is a program for watching free online TV channels. It automatically finds over 1400 channels and have an online updater to keep the channel list updated. This program is completely free of charge and I would like it to stay this way so please donate some money to support it!


Features:
---------
Watch over 1400 free online TV channels!
User friendly interface with inbuilt channel list.
Channel updater that keeps your list syncronised with the list at World Wide Internet TV (wwitv.com)
Program updater automaticly keeps your program up to date.
Powerfull search function lets you easely find any channel.
Favorite list to keep a track of your favorite channels.
Absolutely no spyware/adware or malware included!


Requirements:
-------------
Windows Media Player
Real Player


Known problems:
---------------
Some channels doesn't start:
That's in most cases a problem with the server streaming the channel and not a bug in JLC's Internet TV, so there is nothing I can do about this.

Problems with video or audio not working:
This is in most cases a problem with your codecs, I'm not shure how to fix this yet.

If you discover any bugs or problems then please let me know and I will try to fix them! And I will hopefully make a FAQ soon.


Credits:
--------
WWITV.com:
Please remember that this wouldn't at all be possible without the great WWITV page. They've also been nice enough to cooperate with me lately and made it much easier for my program to access their database.

PureBaic:
This little program is programmed in the great programming language called PureBasic, thank you very much Fantaisie Software for this great product and the purebasic community for all their help!


Version history:
----------------
1.0 Beta 1:
First public version.

1.0 Beta 2:
Added:   Sort list
Added:   Visit channel homepage
Added:   Marks played channel with green
Fixed:   Nasty bug where Real Player got the wrong url
Changed: Channel list format (not compatible with old channels.dat or favorites.dat)

1.0 Beta 2a:
Fixed:   Updated the updater since it didn't work anymore...

1.0 Beta 3:
Fixed:   The crash some users had at startup
Added:   Support for different WMP versions (settings window)
Added:   A help file
Changed: New user interface
Changed: Channel updater doesn't create tempoary files anymore

1.0 Beta 3a:
Fixed:   Bug in the channel updater

1.0 Beta 4:
Added:   Search function
Added:   Choose GUI mode
Added:   Choose how you want do download the channels...
Fixed:   Flimmering in the Windows Media Player when resizeing the window

1.0 Beta 4a:
Fixed:   Stupid bug that caused the favorites to be deleted

1.0 Beta 5:
This will hopefully be the latest beta release!
Added:   Will download the help file if it's missing
Added:   Program updater (finally implemented)
Changed: Channel updater now use a database provided by WWITV instead of scanning their pages, this is to reduce the stress on their servers and everybody should update!

1.0 Beta 5b:
Fixed:   Favorites didn't work (silly mistake)
Fixed:   Fixed update check bug after updating...

1.0 Beta 5c:
Added:   Proxy support, uses preconfigured settings
Fixed:   Channel list is now sorted on startup, makes searching easier
Fixed:   Update check will not freeze the program at startup anymore
Fixed:   Country list disappearing at startup

1.0 Beta 5d:
Fixed:   Serious bug where wrong channels was played.

1.0 Beta 5e:
Fixed:   Favorites got duplicated when updating the channels.


License:
--------
You may use JLC's Internet TV freely provided if you acknowledge the following terms and abide by them:

1. JLC's Internet TV must only be distributed in the packages created by Joakim L. Christiansen, the maintainer of the program.
   The packages must remain complete and the components must not be altered in any way.

2. You must not take any charges for the distribution of JLC's Internet TV.

3. You do not challenge JLC's Internet TV's copyright in any way.
